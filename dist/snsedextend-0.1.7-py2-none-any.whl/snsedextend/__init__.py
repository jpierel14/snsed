
import warnings
warnings.filterwarnings('ignore',category=FutureWarning)
#warnings.filterwarnings('ignore',category=ShimWarning)
import definedBands
from .colorCalc import *
from .cc_extrap import *
from .example import *


